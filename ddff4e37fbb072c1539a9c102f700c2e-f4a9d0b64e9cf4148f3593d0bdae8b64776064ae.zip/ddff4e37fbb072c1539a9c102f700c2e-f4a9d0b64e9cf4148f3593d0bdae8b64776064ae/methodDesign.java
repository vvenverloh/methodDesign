

import java.util.*;

public class methodDesign {

    public static void main(String[] args) {

        while(true){ //so system repeats
            Student student = new Student("", "", 0, "", 0, "", 0); //initializing student
            System.out.println("input student's name: ");
            Scanner nameScan = new Scanner(System.in);
            student.setName(nameScan.nextLine()); //setting the name
            System.out.println("input the student's 3 courses: ");
            Scanner courseScan = new Scanner(System.in);
            student.setCourse1(courseScan.next()); //setting the courses
            student.setCourse2(courseScan.next());
            student.setCourse3(courseScan.next());
            System.out.println("input the scores of the student's 3 tests: ");
            Scanner testScan = new Scanner(System.in);
            student.setTest1(testScan.nextInt()); //setting the test scores
            student.setTest2(testScan.nextInt());
            student.setTest3(testScan.nextInt());
            student.getAvg(); //getting the average
            System.out.println(student);
        }
    }
}

class Student {
    //defining variables for student
    String name = "";
    String course1 = "";
    double test1 = 0;
    String course2 = "";
    double test2 = 0;
    String course3 = "";
    double test3 = 0;
    double testAvg = 0;

    public Student(String inName, String inCourse1, double inTest1, String inCourse2, double inTest2, String inCourse3, double inTest3){

        name = inName;
        course1 = inCourse1;
        test1 = inTest1;
        course2 = inCourse2;
        test2 = inTest2;
        course3 = inCourse3;
        test3 = inTest3;

    }
    //getters
    public String getName(){
        return name;
    }
    public String getCourse1(){
        return course1;
    }
    public double getTest1(){
        return test1;
    }
    public String getCourse2(){
        return course2;
    }
    public double getTest2(){
        return test2;
    }
    public String getCourse3(){
        return course3;
    }
    public double getTest3(){
        return test3;
    }
    //setters
    public void setName(String inName){
        name = inName;
    }
    public void setCourse1(String inCourse1){
        course1 = inCourse1;
    }
    public void setTest1 (double inTest1){
        test1 = inTest1;
    }
    public void setCourse2(String inCourse2){
        course2 = inCourse2;
    }
    public void setTest2 (double inTest2){
        test2 = inTest2;
    }
    public void setCourse3(String inCourse3){
        course3 = inCourse3;
    }
    public void setTest3 (double inTest3){
        test3 = inTest3;
    }
    //get average method
    public void getAvg(){
        testAvg = ((test1+test2+test3)/3);
    }
    //final toString method
    public String toString(){
        String result;
        result = "Student: "+name+"\nCourses: "+course1+", "+course2+", "+course3+"\nIndividual test scores: \n"+course1+": "+test1+"\n"+course2+": "+test2+"\n"+course3+": "+test3+"\nTest average: "+testAvg;;
        return result;
    }

}